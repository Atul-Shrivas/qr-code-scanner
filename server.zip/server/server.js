const mongoose=require('mongoose');
const express=require('express');
const app=express();
var cors = require('cors');
app.use(cors());
app.use(express.json());
const DB='mongodb+srv://atulshrivas1996:8823883767@cluster0.h2vgb.mongodb.net/qrdata?retryWrites=true&w=majority'
mongoose.connect(DB,{useCreateIndex:true,useNewUrlParser:true,useUnifiedTopology:true,useFindAndModify:false}).then(()=>{
    console.log("connection has been made");
}).catch(()=>{
    console.log("error found");

 } );
 var nameSchema = new mongoose.Schema({
    name: String,
   });
var Name = mongoose.model("Name", nameSchema);

// app.get("/",(req,res)=>{
//     res.send("connected");
// });
app.post("/savedata",(req,res)=>{
    var myData = new Name(req.body);
    console.log("my data",req.body);
    myData.save()
    .then(item => {
    res.send("item saved to database");
    })
    .catch(err => {
    res.status(400).send("unable to save to database");
    });
});
app.listen(8000,()=>{
console.log("server running");
});

