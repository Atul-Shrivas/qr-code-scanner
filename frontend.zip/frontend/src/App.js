import React, { Component } from "react";
import './App.css';
import QrReader from 'react-qr-reader'
import axios from 'axios'


class App extends React.Component {
  constructor(props){
   super(props);
   this.state={
    result:'No data'
   };
  }
  handleScan = data => {
    if (data) {
      this.setState({
        result: data
      })
    }
  }
  handleError = err => {
    console.error(err)
  }
  saveData (data){
    if(data=='No data'){
      alert('Please Scan a QR code');
      return;
    }else{
      axios.post('http://localhost:8000/savedata',{name:data}).then(()=>{
     console.log('data saved successfully!!!');
  
      }).then(()=>{
        console.log('error occured')
      })
    }
  }
  render() {
    return <div>
<QrReader
          delay={300}
          onError={this.handleError}
          onScan={this.handleScan}
          style={{ width: '30%' }}
        />
        <p>{this.state.result}</p>
        <button onClick={()=>{this.saveData(this.state.result)}}>Save Qr data</button>
     </div>

  }
}
export default App;
